<?php

declare(strict_types=1);

namespace Dotenv\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
    //
}
